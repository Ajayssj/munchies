import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collaborate',
  templateUrl: './collaborate.component.html',
  styleUrls: ['./collaborate.component.css']
})
export class CollaborateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
